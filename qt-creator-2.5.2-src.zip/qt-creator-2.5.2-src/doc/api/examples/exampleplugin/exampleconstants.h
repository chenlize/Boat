#ifndef EXAMPLECONSTANTS_H
#define EXAMPLECONSTANTS_H

namespace Example {
namespace Constants {

const char ACTION_ID[] = "Example.Action";
const char MENU_ID[] = "Example.Menu";

} // namespace Example
} // namespace Constants

#endif // EXAMPLECONSTANTS_H

