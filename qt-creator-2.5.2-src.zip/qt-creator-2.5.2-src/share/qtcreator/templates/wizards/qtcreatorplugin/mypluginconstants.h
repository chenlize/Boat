#ifndef %PluginName:u%CONSTANTS_%CppHeaderSuffix:u%
#define %PluginName:u%CONSTANTS_%CppHeaderSuffix:u%

namespace %PluginName% {
namespace Constants {

const char ACTION_ID[] = "%PluginName%.Action";
const char MENU_ID[] = "%PluginName%.Menu";

} // namespace %PluginName%
} // namespace Constants

#endif // %PluginName:u%CONSTANTS_%CppHeaderSuffix:u%
