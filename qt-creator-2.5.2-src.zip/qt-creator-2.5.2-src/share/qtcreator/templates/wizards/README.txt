Qt Creator custom wizards are located in this directory.

The subdirectories 'helloworld', 'listmodel' and 'scriptgeneratedproject'
are provided as examples.
To see how they work in Qt Creator, rename the 'wizard_sample.xml' files
to 'wizard.xml'.

The command line option -customwizard-verbose can be used to obtain
verbose information while loading the custom wizards.
