#include <cstdio>

int main(int, char **)
{
    std::printf("%MESSAGE%\n");
    return 0;
}
