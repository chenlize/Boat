#include "%INCLUDE%"

%CLASS%::%CLASS%(QWidget *parent)
    : %BASECLASS%(parent)
{
}

%CLASS%::~%CLASS%()
{

}
